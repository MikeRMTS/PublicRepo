import requests

def run_agent():
    print("Agent is now running and ready to perform tasks.")

if __name__ == "__main__":
    run_agent()
